@extends('layouts.app')

@section('content')
<div class="sidebar">
    <ul>
        <li><a href="{{ route('profile') }}" class="{{ request()->routeIs('profile') ? 'active-link' : '' }}">Profils</a></li>
        <li><a href="{{ route('shifts') }}" class="{{ request()->routeIs('shifts') ? 'active-link' : '' }}">Maiņas</a></li>
        <li><a href="{{ route('transports') }}" class="{{ request()->routeIs('transports') ? 'active-link' : '' }}">Transports</a></li>
        <li><a href="{{ route('reports') }}" class="{{ request()->routeIs('reports') ? 'active-link' : '' }}">Atskaites</a></li>
        <li><a href="{{ route('avārijas') }}" class="{{ request()->routeIs('avārijas') ? 'active-link' : '' }}">Avārijas</a></li>
    </ul>
</div>
<div class="content">
    <h1>Transports</h1>
    <p>Informācija par transportu tiks rādīta šeit.</p>
</div>
@endsection
