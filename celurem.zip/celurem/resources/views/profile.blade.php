@extends('layouts.app')

@section('content')
<div class="sidebar">
    <ul>
        <li><a href="{{ route('profile') }}" class="{{ request()->routeIs('profile') ? 'active-nav-link' : '' }}">Profils</a></li>
        <li><a href="{{ route('shifts') }}" class="{{ request()->routeIs('shifts') ? 'active-nav-link' : '' }}">Maiņas</a></li>
        <li><a href="{{ route('transports') }}" class="{{ request()->routeIs('transports') ? 'active-nav-link' : '' }}">Transports</a></li>
        <li><a href="{{ route('reports') }}" class="{{ request()->routeIs('reports') ? 'active-nav-link' : '' }}">Atskaites</a></li>
        <li><a href="{{ route('incidents.index') }}" class="{{ request()->routeIs('incidents.index') ? 'active-nav-link' : '' }}">Avārijas</a></li>
        <li>
            <form method="POST" action="{{ route('logout') }}" class="logout-form">
                @csrf
                <button type="submit" class="logout-button">Iziet</button>
            </form>
        </li>
    </ul>
</div>
<div class="content">
    @if (session('status'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
            {{ session('status') }}
        </div>
    @endif

    @if (session('error'))
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            {{ session('error') }}
        </div>
    @endif
    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Profile Update Form -->
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h2 class="text-xl font-bold text-gray-800 mb-4">Profila Informācija</h2>
            <form method="POST" action="{{ route('profile.update') }}" class="space-y-4">
                @csrf
                @method('PATCH')
                
                <!-- User ID (Read-only) -->
                <div>
                    <label for="user_id" class="block text-sm font-medium text-gray-700">Lietotāja ID</label>
                    <input type="text" id="user_id" value="{{ auth()->user()->id }}" class="mt-1 block w-full rounded-md border-gray-300 bg-gray-100" readonly disabled>
                </div>

                <!-- Username -->
                <div>
                    <label for="username" class="block text-sm font-medium text-gray-700">Lietotājvārds</label>
                    <input type="text" name="username" id="username" value="{{ auth()->user()->name }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    @error('username')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Email -->
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700">E-pasts</label>
                    <input type="email" name="email" id="email" value="{{ auth()->user()->email }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    @error('email')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Current Password -->
                <div>
                    <label for="current_password" class="block text-sm font-medium text-gray-700">Pašreizējā Parole</label>
                    <input type="password" name="current_password" id="current_password" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    @error('current_password')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <!-- New Password -->
                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700">Jaunā Parole</label>
                    <input type="password" name="password" id="password" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    @error('password')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Confirm Password -->
                <div>
                    <label for="password_confirmation" class="block text-sm font-medium text-gray-700">Apstiprināt Jauno Paroli</label>
                    <input type="password" name="password_confirmation" id="password_confirmation" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                </div>

                <div class="flex justify-end">
                    <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                        Saglabāt Izmaiņas
                    </button>
                </div>
            </form>
        </div>

        <!-- Delete Account Section -->
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h2 class="text-xl font-bold text-red-600 mb-4">Dzēst Kontu</h2>
            <p class="text-gray-600 mb-4">
                Kad jūsu konts tiks dzēsts, visi tā resursi un dati tiks neatgriezeniski izdzēsti. Pirms konta dzēšanas, lūdzu, lejupielādējiet visus datus vai informāciju, ko vēlaties saglabāt.
            </p>

            <!-- Request Verification Code Form -->
            <form method="POST" action="{{ route('profile.request-delete-code') }}" class="space-y-4 mb-6" id="requestCodeForm">
                @csrf
                <div>
                    <label for="password_for_code" class="block text-sm font-medium text-gray-700">Parole</label>
                    <input type="password" name="password" id="password_for_code" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" placeholder="Ievadiet savu paroli, lai saņemtu kodu">
                    @error('password')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div class="flex justify-end">
                    <button type="submit" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                        Saņemt Verifikācijas Kodu
                    </button>
                </div>
            </form>

            <!-- Delete Account Form -->
            <form method="POST" action="{{ route('profile.destroy') }}" class="space-y-4" id="deleteAccountForm">
                @csrf
                @method('DELETE')

                <!-- Verification Code -->
                <div>
                    <label for="verification_code" class="block text-sm font-medium text-gray-700">Verifikācijas Kods</label>
                    <input type="text" name="verification_code" id="verification_code" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" placeholder="Ievadiet kodu no e-pasta">
                    @error('verification_code')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Password Confirmation -->
                <div>
                    <label for="password_confirmation_delete" class="block text-sm font-medium text-gray-700">Parole</label>
                    <input type="password" name="password" id="password_confirmation_delete" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" placeholder="Ievadiet savu paroli, lai apstiprinātu">
                    @error('password')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div class="flex justify-end">
                    <button type="button" onclick="confirmDelete()" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                        Dzēst Kontu
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function confirmDelete() {
    if (confirm('Vai tiešām vēlaties dzēst savu kontu? Šo darbību nevar atsaukt.')) {
        document.getElementById('deleteAccountForm').submit();
    }
}
</script>
@endsection
