@props(['active'])

@php
$classes = ($active ?? false)
    ? 'block px-4 py-3 text-sm font-medium text-blue-600 bg-blue-50 rounded-md hover:bg-blue-100 transition-colors duration-150'
    : 'block px-4 py-3 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-100 transition-colors duration-150';
@endphp

<a {{ $attributes->merge(['class' => $classes]) }}>
    {{ $slot }}
</a> 