<x-app-layout>
    @section('title', 'Dashboard')

    @section('content')
        <h1>Dashboard</h1>
        <p>Welcome!</p>
    @endsection
</x-app-layout>
