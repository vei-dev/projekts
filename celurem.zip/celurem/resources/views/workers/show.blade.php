<!DOCTYPE html>
<html>
<head>
    <title>Show Worker</title>
</head>
<body>
    <h1>Show Worker</h1>

    <div>
        <strong>ID:</strong> {{ $worker->id }}
    </div>
    <div>
        <strong>Name:</strong> {{ $worker->name }}
    </div>
    <div>
        <strong>Email:</strong> {{ $worker->email }}
    </div>
    <a href="{{ route('workers.index') }}">Back</a>
</body>
</html>
