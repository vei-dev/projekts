<!DOCTYPE html>
<html>
<head>
    <title>Workers</title>
</head>
<body>
    <h1>Workers</h1>

    <a href="{{ route('workers.create') }}">Create New Worker</a>

    @if ($message = Session::get('success'))
        <div>
            {{ $message }}
        </div>
    @endif

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($workers as $worker)
                <tr>
                    <td>{{ $worker->id }}</td>
                    <td>{{ $worker->name }}</td>
                    <td>{{ $worker->email }}</td>
                    <td>
                        <a href="{{ route('workers.show', $worker->id) }}">Show</a>
                        <a href="{{ route('workers.edit', $worker->id) }}">Edit</a>
                        <form action="{{ route('workers.destroy', $worker->id) }}" method="POST">
                            @csrf
                            @method('DELETE')
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
