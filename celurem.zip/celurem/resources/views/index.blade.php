<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pieslēgties</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body style="background-color: white; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0;">
    <div class="login-register-box" style="background-color: #f0f0f0; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); width: 350px; text-align: center;">
        <h2 style="color: #333; margin-bottom: 20px;">Pieslēgties</h2>
        <form method="POST" action="{{ route('login') }}">
            @csrf
            <div class="form-group">
                <label for="username">Epasts/Lietotājvārds:</label>
                <input type="text" id="username" name="email" autocomplete="email" style="width: calc(100% - 20px); padding: 10px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            <div class="form-group">
                <label for="password">Parole:</label>
                <input type="password" id="password" name="password" autocomplete="current-password" style="width: calc(100% - 20px); padding: 10px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            <button type="submit" class="btn" style="background-color: #007bff; color: white; padding: 12px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; width: 100%;">Pieslēgties</button>
        </form>
        <div class="register-link">
            <a href="{{ route('register') }}" style="color: #007bff; text-decoration: none; margin-top: 15px; display: block;">Reģistrēties</a>
        </div>
    </div>
    <script src="{{ asset('js/script.js') }}"></script>
</body>
</html>
