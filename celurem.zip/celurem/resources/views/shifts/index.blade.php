<x-app-layout>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="flex justify-between items-center mb-6">
                <h2 class="font-semibold text-xl text-gray-800">
                    {{ __('Maiņas') }}
                </h2>
                @if(Auth::user()?->hasRole('admin') || Auth::user()?->hasRole('dispatcher'))
                    <a href="{{ route('shifts.create') }}" 
                       class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:bg-blue-700 active:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition ease-in-out duration-150 shadow-lg hover:shadow-xl">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                        </svg>
                        Izveidot Maiņu
                    </a>
                @endif
            </div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    @if(session('success'))
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                            <span class="block sm:inline">{{ session('success') }}</span>
                        </div>
                    @endif

                    <div class="overflow-x-auto">
                        <table class="min-w-full table-auto">
                            <thead>
                                <tr class="bg-gray-100">
                                    <th class="px-6 py-3 text-left">Datums</th>
                                    <th class="px-6 py-3 text-left">Maiņas Tips</th>
                                    <th class="px-6 py-3 text-left">Lokācija</th>
                                    <th class="px-6 py-3 text-left">Izveidoja</th>
                                    @if(Auth::user()?->hasRole('admin') || Auth::user()?->hasRole('dispatcher'))
                                        <th class="px-6 py-3 text-left">Darbības</th>
                                    @endif
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($shifts as $shift)
                                    <tr class="border-b">
                                        <td class="px-6 py-4">{{ $shift->date->format('d.m.Y') }}</td>
                                        <td class="px-6 py-4">{{ $shift->shift_type === 'day' ? 'Diena' : 'Nakts' }}</td>
                                        <td class="px-6 py-4">{{ $shift->location }}</td>
                                        <td class="px-6 py-4">{{ $shift->creator->name }}</td>
                                        @if(Auth::user()?->hasRole('admin') || Auth::user()?->hasRole('dispatcher'))
                                            <td class="px-6 py-4">
                                                <div class="flex space-x-2">
                                                    <a href="{{ route('shifts.edit', $shift) }}" class="text-blue-600 hover:text-blue-900">Rediģēt</a>
                                                    <form action="{{ route('shifts.destroy', $shift) }}" method="POST" class="inline">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="text-red-600 hover:text-red-900" onclick="return confirm('Vai tiešām vēlaties dzēst šo maiņu?')">
                                                            Dzēst
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        @endif
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5" class="px-6 py-4 text-center">Nav nevienas maiņas</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout> 