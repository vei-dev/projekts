<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Pievienot Maiņu') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <form method="POST" action="{{ route('shifts.store') }}" class="space-y-6">
                        @csrf

                        <div>
                            <x-input-label for="date" :value="__('Datums')" />
                            <x-text-input id="date" name="date" type="date" class="mt-1 block w-full" :value="old('date')" required autofocus />
                            <x-input-error class="mt-2" :messages="$errors->get('date')" />
                        </div>

                        <div>
                            <x-input-label for="shift_type" :value="__('Maiņas Tips')" />
                            <select id="shift_type" name="shift_type" class="mt-1 block w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm" required>
                                <option value="day" {{ old('shift_type') === 'day' ? 'selected' : '' }}>Diena</option>
                                <option value="night" {{ old('shift_type') === 'night' ? 'selected' : '' }}>Nakts</option>
                            </select>
                            <x-input-error class="mt-2" :messages="$errors->get('shift_type')" />
                        </div>

                        <div>
                            <x-input-label for="location" :value="__('Lokācija')" />
                            <x-text-input id="location" name="location" type="text" class="mt-1 block w-full" :value="old('location')" required />
                            <x-input-error class="mt-2" :messages="$errors->get('location')" />
                        </div>

                        <div class="flex items-center gap-4">
                            <x-primary-button>{{ __('Saglabāt') }}</x-primary-button>
                            <a href="{{ route('shifts.index') }}" class="text-gray-600 hover:text-gray-900">Atcelt</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout> 