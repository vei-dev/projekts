<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Maiņas Detaļas') }}
            </h2>
            <a href="{{ route('shifts.index') }}" class="text-gray-600 hover:text-gray-900">
                Atpakaļ uz sarakstu
            </a>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <dl class="grid grid-cols-1 gap-6 sm:grid-cols-2">
                        <div>
                            <dt class="text-sm font-medium text-gray-500">Datums</dt>
                            <dd class="mt-1 text-sm text-gray-900">{{ $shift->date->format('d.m.Y') }}</dd>
                        </div>

                        <div>
                            <dt class="text-sm font-medium text-gray-500">Maiņas Tips</dt>
                            <dd class="mt-1 text-sm text-gray-900">{{ $shift->shift_type === 'day' ? 'Diena' : 'Nakts' }}</dd>
                        </div>

                        <div>
                            <dt class="text-sm font-medium text-gray-500">Lokācija</dt>
                            <dd class="mt-1 text-sm text-gray-900">{{ $shift->location }}</dd>
                        </div>

                        <div>
                            <dt class="text-sm font-medium text-gray-500">Izveidoja</dt>
                            <dd class="mt-1 text-sm text-gray-900">{{ $shift->creator->name }}</dd>
                        </div>

                        <div>
                            <dt class="text-sm font-medium text-gray-500">Izveidots</dt>
                            <dd class="mt-1 text-sm text-gray-900">{{ $shift->created_at->format('d.m.Y H:i') }}</dd>
                        </div>

                        <div>
                            <dt class="text-sm font-medium text-gray-500">Pēdējo reizi atjaunināts</dt>
                            <dd class="mt-1 text-sm text-gray-900">{{ $shift->updated_at->format('d.m.Y H:i') }}</dd>
                        </div>
                    </dl>

                    @if(Auth::user()?->hasRole('admin') || Auth::user()?->hasRole('dispatcher'))
                        <div class="mt-6 flex space-x-4">
                            <a href="{{ route('shifts.edit', $shift) }}" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                Rediģēt
                            </a>
                            <form action="{{ route('shifts.destroy', $shift) }}" method="POST" class="inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded" onclick="return confirm('Vai tiešām vēlaties dzēst šo maiņu?')">
                                    Dzēst
                                </button>
                            </form>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout> 