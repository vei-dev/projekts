<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Pievienot avāriju') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <form action="{{ route('incidents.store') }}" method="POST">
                        @csrf

                        <div class="mb-4">
                            <label for="description" class="block text-sm font-medium text-gray-700">{{ __('Apraksts') }}</label>
                            <textarea name="description" id="description" rows="3" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">{{ old('description') }}</textarea>
                            @error('description')
                                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>

                        <div class="mb-4">
                            <label for="severity" class="block text-sm font-medium text-gray-700">{{ __('Gravitāte') }}</label>
                            <select name="severity" id="severity" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option value="low" {{ old('severity') == 'low' ? 'selected' : '' }}>{{ __('Zema') }}</option>
                                <option value="medium" {{ old('severity') == 'medium' ? 'selected' : '' }}>{{ __('Vidēja') }}</option>
                                <option value="high" {{ old('severity') == 'high' ? 'selected' : '' }}>{{ __('Augsta') }}</option>
                            </select>
                            @error('severity')
                                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>

                        <div class="mb-4">
                            <label for="status" class="block text-sm font-medium text-gray-700">{{ __('Statuss') }}</label>
                            <select name="status" id="status" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option value="reported" {{ old('status') == 'reported' ? 'selected' : '' }}>{{ __('Reģistrēta') }}</option>
                                <option value="investigating" {{ old('status') == 'investigating' ? 'selected' : '' }}>{{ __('Tiek izmeklēta') }}</option>
                                <option value="resolved" {{ old('status') == 'resolved' ? 'selected' : '' }}>{{ __('Atrisināta') }}</option>
                            </select>
                            @error('status')
                                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>

                        <div class="mb-4">
                            <label for="shift_id" class="block text-sm font-medium text-gray-700">{{ __('Maiņa') }}</label>
                            <select name="shift_id" id="shift_id" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option value="">{{ __('Izvēlieties maiņu') }}</option>
                                @foreach($shifts as $shift)
                                    <option value="{{ $shift->id }}" {{ old('shift_id') == $shift->id ? 'selected' : '' }}>
                                        {{ $shift->name }}
                                    </option>
                                @endforeach
                            </select>
                            @error('shift_id')
                                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>

                        <div class="flex items-center justify-end mt-4">
                            <a href="{{ route('incidents.index') }}" class="text-gray-600 hover:text-gray-900 mr-4">
                                {{ __('Atcelt') }}
                            </a>
                            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                {{ __('Saglabāt') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout> 