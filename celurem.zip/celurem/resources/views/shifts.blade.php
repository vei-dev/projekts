@extends('layouts.app')

@section('title', 'Shifts')

@section('content')
    <h1>Shifts</h1>
    <p>Shifts content here.</p>
@endsection
