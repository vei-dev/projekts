@extends('layouts.app')

@section('title', 'Transport')

@section('content')
    <h1>Transport</h1>
    <p>Transport content here.</p>
@endsection
